Test case: stop_without_zone_id
Expected info: Stop missing zone_id in route with zone-dependent fare rules
Error: stops.txt has stops without zone_id but fare_rules.txt references zone_a and zone_b
