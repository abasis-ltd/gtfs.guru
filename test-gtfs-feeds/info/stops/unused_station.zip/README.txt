Test case: unused_station
Expected info: Station has location_type=1 but does not appear in any stop's parent_station
Error: station1 is defined as a station but no stops reference it as their parent_station
