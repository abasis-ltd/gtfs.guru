Test case: platform_without_parent_station
Expected info: Platform has no parent_station field set
Error: platform1 has location_type=4 (boarding area/platform) but no parent_station
