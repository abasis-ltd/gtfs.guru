Test case: transfer_distance_above_2_km
Expected info: Transfer distance from stop to stop is larger than 2 km
Error: Transfer from stop1 to stop3 is approximately 5 km apart
