Test case: unknown_column
Expected info: A column name is unknown
Error: agency.txt contains unknown_custom_column which is not in the GTFS spec
