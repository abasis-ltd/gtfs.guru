Test case: unknown_file
Expected info: A file is unknown
Error: custom_data.txt is not a standard GTFS file
