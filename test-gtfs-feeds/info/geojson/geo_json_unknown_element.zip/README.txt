Test case: geo_json_unknown_element
Expected info: Unknown elements in locations.geojson file
Error: locations.geojson contains unknown elements like unknown_element, custom_field, extra_property
