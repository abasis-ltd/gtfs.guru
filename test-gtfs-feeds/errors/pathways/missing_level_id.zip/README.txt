Test case: missing_level_id
Expected error: Pathway with stairs (pathway_mode=4) requires level_id on connected stops
Error: pathway2 uses stairs but stop1 and node1 have no level_id defined
