Test case: pathway_to_platform_with_boarding_areas
Expected error: Pathway leads to platform that has boarding areas - should lead to boarding areas instead
Error: pathway2 leads to platform1 which has boarding areas (boarding1, boarding2), pathways should lead to boarding areas directly
