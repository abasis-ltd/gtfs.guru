ERROR: bidirectional_exit_gate
Description: Exit gates (pathway_mode=7) must not be bidirectional.
In this test case, pathways.txt has pathway1 with pathway_mode=7 (exit gate) and is_bidirectional=1.
Expected error: bidirectional_exit_gate for pathways.txt
