Test case: u_r_i_syntax_error
Expected error: URI has invalid syntax that cannot be parsed
Error: agency_url contains spaces which makes it an invalid URI
