ERROR: invalid_row_length
Description: A row has a different number of values than specified by the CSV header.
In this test case, agency.txt has 6 values in the data row but only 4 columns in header.
Expected error: invalid_row_length for agency.txt
