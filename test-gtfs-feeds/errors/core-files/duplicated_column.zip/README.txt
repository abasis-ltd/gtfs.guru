ERROR: duplicated_column
Description: The CSV header has the same column name repeated.
In this test case, agency.txt has "agency_name" column twice.
Expected error: duplicated_column for agency.txt
