ERROR: duplicate_key
Description: The values of the given key and rows are duplicates.
In this test case, agency.txt has two agencies with the same agency_id "agency1".
Expected error: duplicate_key for agency.txt (agency_id)
