ERROR: missing_required_column
Description: A required column is missing in the input file.
In this test case, agency.txt is missing the required "agency_name" column.
Expected error: missing_required_column for agency.txt (agency_name)
