Test case: missing_stop_times_record
Expected error: Only one stop_times record is present when two are required for pickup/dropoff windows
Error: trip1 has pickup/dropoff windows with MustPhone but only a single stop_times record
