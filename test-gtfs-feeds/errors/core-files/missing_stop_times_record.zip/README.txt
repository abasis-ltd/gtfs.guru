Test case: missing_stop_times_record
Expected error: Trip defined in trips.txt has no corresponding records in stop_times.txt
Error: trip2 is defined but has no stop_times entries
