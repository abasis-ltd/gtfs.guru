ERROR: missing_required_field
Description: A required field has no value in the row.
In this test case, agency.txt has an empty "agency_name" field in the data row.
Expected error: missing_required_field for agency.txt (agency_name)
