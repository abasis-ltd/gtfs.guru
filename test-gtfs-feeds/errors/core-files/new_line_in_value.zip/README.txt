ERROR: new_line_in_value
Description: A field value contains a newline character.
In this test case, agency.txt has a newline character in "agency_name" field.
Expected error: new_line_in_value for agency.txt
