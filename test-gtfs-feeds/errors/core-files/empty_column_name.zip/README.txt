ERROR: empty_column_name
Description: A column name is empty in the CSV header.
In this test case, agency.txt has an empty column name (third column).
Expected error: empty_column_name for agency.txt
