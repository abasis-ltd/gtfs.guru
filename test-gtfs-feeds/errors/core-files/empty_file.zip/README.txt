ERROR: empty_file
Description: A required file has headers but no data rows.
In this test case, stops.txt has only headers, no actual stops.
Expected error: empty_file for stops.txt
