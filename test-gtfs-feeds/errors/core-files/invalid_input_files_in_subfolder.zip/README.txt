Test case: invalid_input_files_in_subfolder
Expected error: GTFS files are located in a subfolder instead of the root of the archive
Error: All GTFS files are in subfolder/ instead of the archive root
Note: When creating ZIP, include the subfolder structure to trigger this error
