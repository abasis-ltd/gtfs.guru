ERROR: decreasing_shape_distance
Description: shape_dist_traveled values must not decrease along a shape.
In this test case, shapes.txt has shape_dist_traveled decreasing from 200 to 100 between points 2 and 3.
Expected error: decreasing_shape_distance for shapes.txt
