Test case: transfer_with_invalid_trip_and_route
Expected error: Transfer references a trip that does not belong to the specified route
Error: trip1 belongs to route1 but transfer specifies from_route_id=route2 with from_trip_id=trip1
