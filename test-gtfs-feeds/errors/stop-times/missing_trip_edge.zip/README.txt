ERROR: missing_trip_edge
Description: First and last stop of a trip must define both arrival_time and departure_time.
In this test case, stop_times.txt has the first stop (stop1) without arrival_time and departure_time.
Expected error: missing_trip_edge for stop_times.txt
