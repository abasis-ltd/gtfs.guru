ERROR: stop_time_timepoint_without_times
Description: Records with timepoint=1 must define both arrival_time and departure_time.
In this test case, stop_times.txt has stop2 with timepoint=1 but no arrival_time or departure_time.
Expected error: stop_time_timepoint_without_times for stop_times.txt
