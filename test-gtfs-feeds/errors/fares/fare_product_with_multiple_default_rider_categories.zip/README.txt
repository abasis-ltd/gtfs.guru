Test case: fare_product_with_multiple_default_rider_categories
Expected error: Multiple rider categories are marked as default (is_default_category=1)
Error: Both adult and senior rider categories have is_default_category=1
