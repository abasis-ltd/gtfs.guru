ERROR: inconsistent_agency_timezone
Description: Agencies have been found to have different timezones.
In this test case, agency.txt has two agencies with different timezones:
- agency1: America/New_York
- agency2: America/Los_Angeles
Expected error: inconsistent_agency_timezone for agency.txt
