ERROR: start_and_end_range_out_of_order
Description: Date or time fields are out of order (start comes after end).
In this test case, calendar.txt has start_date (20251231) after end_date (20250101).
Expected error: start_and_end_range_out_of_order for calendar.txt
