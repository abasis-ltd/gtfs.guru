ERROR: invalid_date
Description: Date must have the YYYYMMDD format.
In this test case, calendar.txt has start_date in wrong format "2025-01-01" instead of "20250101".
Expected error: invalid_date for calendar.txt (start_date)
