ERROR: invalid_timezone
Description: Timezone must be a valid IANA timezone name.
In this test case, agency.txt has agency_timezone "Invalid/Timezone" which is not a valid IANA timezone.
Expected error: invalid_timezone for agency.txt (agency_timezone)
