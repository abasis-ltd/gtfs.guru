ERROR: invalid_language_code
Description: Language codes must follow IETF BCP 47.
In this test case, agency.txt has agency_lang "invalid-lang" which is not a valid BCP 47 language code.
Expected error: invalid_language_code for agency.txt (agency_lang)
