ERROR: point_near_pole
Description: A point is too close to the North or South Pole.
In this test case, stops.txt has stop1 at latitude 89.9999 which is very near the North Pole.
Expected error: point_near_pole for stops.txt
