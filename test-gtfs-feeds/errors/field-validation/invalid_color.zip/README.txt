ERROR: invalid_color
Description: A color must be encoded as a six-digit hexadecimal number (RRGGBB format without #).
In this test case, routes.txt has route_color "#FF0000" with a hash symbol instead of "FF0000".
Expected error: invalid_color for routes.txt (route_color)
