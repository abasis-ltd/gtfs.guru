ERROR: point_near_origin
Description: A point is too close to origin (0, 0) - likely a data error.
In this test case, stops.txt has stop1 at coordinates (0.0001, 0.0001) which is near origin.
Expected error: point_near_origin for stops.txt
