ERROR: invalid_integer
Description: Field cannot be parsed as an integer.
In this test case, routes.txt has route_type "not-an-integer" which cannot be parsed as an integer.
Expected error: invalid_integer for routes.txt (route_type)
