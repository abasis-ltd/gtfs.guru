ERROR: number_out_of_range
Description: The value in the column is out of range.
In this test case, stops.txt has stop_lat "100.0" which is outside valid range [-90, 90].
Expected error: number_out_of_range for stops.txt (stop_lat)
