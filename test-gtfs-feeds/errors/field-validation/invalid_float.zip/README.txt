ERROR: invalid_float
Description: Field cannot be parsed as a floating point number.
In this test case, stops.txt has stop_lat "not-a-number" which cannot be parsed as a float.
Expected error: invalid_float for stops.txt (stop_lat)
