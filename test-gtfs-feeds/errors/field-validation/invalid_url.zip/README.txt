ERROR: invalid_url
Description: Field contains a malformed URL.
In this test case, agency.txt has agency_url "not-a-valid-url" which is not a valid URL.
Expected error: invalid_url for agency.txt (agency_url)
