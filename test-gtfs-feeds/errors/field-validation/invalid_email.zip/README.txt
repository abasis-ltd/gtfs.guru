ERROR: invalid_email
Description: Field contains a malformed email address.
In this test case, agency.txt has agency_email "not-a-valid-email" which is not a valid email address.
Expected error: invalid_email for agency.txt (agency_email)
