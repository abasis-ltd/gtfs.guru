ERROR: invalid_time
Description: Time must be in H:MM:SS, HH:MM:SS, or HHH:MM:SS format.
In this test case, stop_times.txt has arrival_time "8:00AM" instead of "08:00:00".
Expected error: invalid_time for stop_times.txt (arrival_time)
