ERROR: start_and_end_range_equal
Description: Two date or time fields are equal.
In this test case, frequencies.txt has start_time equal to end_time (08:00:00).
Expected error: start_and_end_range_equal for frequencies.txt
