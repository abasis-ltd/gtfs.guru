ERROR: route_both_short_and_long_name_missing
Description: Both route_short_name and route_long_name are missing.
In this test case, routes.txt has route1 with both route_short_name and route_long_name empty.
Expected error: route_both_short_and_long_name_missing for routes.txt
