ERROR: missing_calendar_and_calendar_date_files
Description: At least one of calendar.txt or calendar_dates.txt must be provided.
In this test case, neither calendar.txt nor calendar_dates.txt is present.
Expected error: missing_calendar_and_calendar_date_files
