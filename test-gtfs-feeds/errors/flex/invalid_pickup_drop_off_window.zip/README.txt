Test case: invalid_pickup_drop_off_window
Expected error: end_pickup_drop_off_window is before start_pickup_drop_off_window
Error: stop1 has start=10:00:00 but end=08:00:00 (end is before start)
