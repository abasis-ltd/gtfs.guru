Test case: forbidden_drop_off_type
Expected error: drop_off_type is forbidden when pickup/drop-off windows are defined
Error: stop_times has drop_off_type with start/end_pickup_drop_off_window
