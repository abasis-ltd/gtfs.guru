Test case: forbidden_arrival_or_departure_time
Expected error: arrival_time and departure_time are forbidden when pickup/drop-off windows are defined
Error: stop_times has both arrival_time/departure_time AND start/end_pickup_drop_off_window
