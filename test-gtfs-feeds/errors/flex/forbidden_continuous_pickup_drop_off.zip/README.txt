Test case: forbidden_continuous_pickup_drop_off
Expected error: continuous_pickup/continuous_drop_off are forbidden for flex trips with pickup/drop-off windows
Error: Route has continuous_pickup=1 but trip uses pickup/drop-off windows
