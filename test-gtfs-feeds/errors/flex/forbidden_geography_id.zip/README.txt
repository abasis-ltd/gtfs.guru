Test case: forbidden_geography_id
Expected error: location_id/geography_id is forbidden when stop_id is defined in stop_times
Error: stop_times has both stop_id and location_id defined
