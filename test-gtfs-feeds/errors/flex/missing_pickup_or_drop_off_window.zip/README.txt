Test case: missing_pickup_or_drop_off_window
Expected error: Only one of start/end_pickup_drop_off_window is defined
Error: stop1 has start_pickup_drop_off_window but missing end_pickup_drop_off_window
