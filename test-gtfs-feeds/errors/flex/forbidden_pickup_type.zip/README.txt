Test case: forbidden_pickup_type
Expected error: pickup_type is forbidden when pickup/drop-off windows are defined
Error: stop_times has pickup_type with start/end_pickup_drop_off_window
