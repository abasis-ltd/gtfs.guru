Test case: overlapping_zone_and_pickup_drop_off_window
Expected error: Same location_group has overlapping pickup/drop-off windows in same trip
Error: zone1 has overlapping windows 08:00-09:00 and 08:30-09:30 for the same trip
