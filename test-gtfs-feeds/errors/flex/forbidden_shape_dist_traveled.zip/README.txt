Test case: forbidden_shape_dist_traveled
Expected error: shape_dist_traveled is forbidden when pickup/drop-off windows are defined
Error: stop_times has shape_dist_traveled with start/end_pickup_drop_off_window
