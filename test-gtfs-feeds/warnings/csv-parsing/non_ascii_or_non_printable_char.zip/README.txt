Test case: non_ascii_or_non_printable_char
Expected warning: ID fields contain non-ASCII or unprintable characters
Error: agency_id contains Cyrillic characters 'агенство1' instead of ASCII
