Test case: empty_row
Expected warning: CSV rows containing only spaces may be misinterpreted by parsers
Error: agency.txt has a row containing only spaces
