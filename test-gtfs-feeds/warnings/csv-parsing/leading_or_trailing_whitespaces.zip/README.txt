Test case: leading_or_trailing_whitespaces
Expected warning: CSV values should not have extraneous spacing
Error: agency_name has leading and trailing spaces ' Test Transit Agency '
