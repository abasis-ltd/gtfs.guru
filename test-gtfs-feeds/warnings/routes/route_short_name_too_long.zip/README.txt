Test case: route_short_name_too_long
Expected warning: Short name exceeds 12 character limit
Error: route_short_name 'VeryLongRouteName' has 17 characters (> 12)
