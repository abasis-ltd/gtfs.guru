Test case: duplicate_route_name
Expected warning: Routes with identical short/long names need differentiation
Error: route1 and route2 have identical short_name 'R1' and long_name 'Main Street'
