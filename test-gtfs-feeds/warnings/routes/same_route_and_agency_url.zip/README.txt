Test case: same_route_and_agency_url
Expected warning: Route URLs should differ from agency URLs
Error: route_url 'https://example.com' is identical to agency_url
