Test case: route_color_contrast
Expected warning: Route colors lack sufficient contrast with text colors
Error: route_color FFFF00 (yellow) and route_text_color FFFFCC (light yellow) have poor contrast
