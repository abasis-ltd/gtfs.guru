Test case: route_long_name_contains_short_name
Expected warning: Long names should not duplicate short name content
Error: route_long_name 'R1 - Route One Downtown Express' contains route_short_name 'R1'
