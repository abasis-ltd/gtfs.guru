Test case: same_name_and_description_for_route
Expected warning: Route descriptions should provide distinct information from names
Error: route_desc 'Route One' is identical to route_long_name
