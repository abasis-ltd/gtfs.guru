Test case: stops_match_shape_out_of_order
Expected warning: Stops match shape points but in wrong order
Warning: stop1 at sequence 1 matches shape point 4, stop2 at sequence 2 matches shape point 1 (backwards)
