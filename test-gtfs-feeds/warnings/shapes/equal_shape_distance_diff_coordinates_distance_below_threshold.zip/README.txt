Test case: equal_shape_distance_diff_coordinates_distance_below_threshold
Expected warning: Two shape points have equal shape_dist_traveled but different coordinates (distance below error threshold)
Warning: Points 2 and 3 have same distance 100.0 but different coordinates (small offset)
