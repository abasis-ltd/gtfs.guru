Test case: stop_has_too_many_matches_for_shape
Expected warning: Stop matches multiple shape points within distance threshold
Warning: stop1 and stop2 both have multiple shape points at same location
