Test case: stop_has_too_many_matches_for_shape
Expected warning: Stop matches more than 20 shape points within distance threshold
Warning: stop1 and stop2 both have more than 20 shape points at near the stop location repeatedly
