Test case: unused_shape
Expected warning: Shape definitions exist but aren't referenced in trips
Error: shape1 is defined in shapes.txt but not referenced by any trip
