Test case: single_shape_point
Expected warning: Shapes require multiple points for proper visualization
Error: shape1 has only one point (sequence 1)
