Test case: stop_too_far_from_shape
Expected warning: Stops should be within 100 meters of shape definitions
Error: stop2 at (40.72, -73.99) is far from shape1 which ends at (40.7132, -74.005)
