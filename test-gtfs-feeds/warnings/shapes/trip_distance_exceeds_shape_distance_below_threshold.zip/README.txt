Test case: trip_distance_exceeds_shape_distance_below_threshold
Expected warning: Trip's shape_dist_traveled exceeds shape's max distance (but within threshold)
Warning: stop_times last shape_dist is 200m but shape max is only 150m (50m difference below error threshold)
