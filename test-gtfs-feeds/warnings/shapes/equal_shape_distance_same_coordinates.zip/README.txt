Test case: equal_shape_distance_same_coordinates
Expected warning: Duplicate shape points with identical coordinates and distance values
Error: shape1 has points 1 and 2 with same coordinates and shape_dist_traveled=0
