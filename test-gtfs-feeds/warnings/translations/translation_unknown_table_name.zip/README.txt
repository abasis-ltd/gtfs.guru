Test case: translation_unknown_table_name
Expected warning: Translations reference non-existent or missing GTFS tables
Error: translations.txt references 'unknown_table' which doesn't exist
