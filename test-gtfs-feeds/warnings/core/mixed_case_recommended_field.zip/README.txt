Test case: mixed_case_recommended_field
Expected warning: Field value uses mixed/upper case when lowercase is recommended
Warning: agency_lang should be lowercase "en" not uppercase "EN"
