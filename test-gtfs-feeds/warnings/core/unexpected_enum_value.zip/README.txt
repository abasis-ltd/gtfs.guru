Test case: unexpected_enum_value
Expected warning: Enum field has value not defined in specification
Warning: wheelchair_boarding=5 is not a valid enum value (valid: 0,1,2)
