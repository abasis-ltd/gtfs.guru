Test case: missing_recommended_field
Expected warning: Recommended field is present but empty
Warning: trip_headsign is recommended but empty for trip1
