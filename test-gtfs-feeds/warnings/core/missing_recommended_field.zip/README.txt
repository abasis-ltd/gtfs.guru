Test case: missing_recommended_field
Expected warning: Recommended field is missing for single-agency feed
Warning: agency_id is recommended but empty for agency1
