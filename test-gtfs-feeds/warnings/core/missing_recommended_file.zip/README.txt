Test case: missing_recommended_file
Expected warning: Recommended file feed_info.txt is missing
Warning: feed_info.txt is recommended but not present in the feed
