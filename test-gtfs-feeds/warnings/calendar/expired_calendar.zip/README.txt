Test case: expired_calendar
Expected warning: Datasets should exclude already-expired service date ranges
Error: calendar service1 has end_date 20241231 which is in the past
