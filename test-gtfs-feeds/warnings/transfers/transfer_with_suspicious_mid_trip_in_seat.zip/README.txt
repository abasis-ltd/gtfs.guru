Test case: transfer_with_suspicious_mid_trip_in_seat
Expected warning: In-seat transfer (type=4) at stop that is not first/last stop of trips
Warning: In-seat transfer at stop2 which is in the middle of both trip1 and trip2
