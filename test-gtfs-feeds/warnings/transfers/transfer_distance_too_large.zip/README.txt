Test case: transfer_distance_too_large
Expected warning: Transfer distances exceed 10 km threshold
Error: Transfer from stop1 (40.7128,-74.006) to stop2 (40.82,-73.9) is >10km apart
