Test case: inconsistent_agency_lang
Expected warning: Multiple agencies have different agency_lang values
Warning: agency1 has lang=en, agency2 has lang=fr - agencies should use consistent language
