Test case: unusable_trip
Expected warning: Trips must have more than one stop to be usable
Error: trip1 has only one stop_time entry
