Test case: missing_bike_allowance
Expected warning: trips.txt has bikes_allowed column but value is empty
Warning: trip1 has bikes_allowed column but no value specified
