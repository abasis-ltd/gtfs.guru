Test case: unused_trip
Expected warning: Trip definitions lack any stop_times references
Error: trip2 is defined but has no stop_times entries
