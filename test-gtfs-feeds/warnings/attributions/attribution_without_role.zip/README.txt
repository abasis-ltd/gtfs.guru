Test case: attribution_without_role
Expected warning: At least one of is_producer, is_operator, or is_authority should be set to 1
Error: attr1 has all role fields set to 0
