Test case: more_than_one_entity
Expected warning: Single-entity files like feed_info.txt contain multiple rows
Error: feed_info.txt has 2 rows instead of 1
