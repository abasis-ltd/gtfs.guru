Test case: feed_expiration_date30_days
Expected warning: Dataset should cover at least the next 30 days of service
Error: feed_end_date is within 30 days but after 7 days (set to 20250115)
