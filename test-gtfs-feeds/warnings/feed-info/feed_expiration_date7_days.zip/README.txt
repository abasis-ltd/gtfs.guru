Test case: feed_expiration_date7_days
Expected warning: Dataset should be valid for at least the next 7 days
Error: feed_end_date is within 7 days (set to 20250103)
