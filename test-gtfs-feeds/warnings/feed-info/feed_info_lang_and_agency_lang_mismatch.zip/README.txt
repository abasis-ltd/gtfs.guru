Test case: feed_info_lang_and_agency_lang_mismatch
Expected warning: Feed and agency language fields should align
Error: feed_lang is 'en' but agency_lang is 'fr'
