Test case: missing_feed_contact_email_and_url
Expected warning: Best practices recommend providing contact methods
Error: feed_info.txt has no feed_contact_email or feed_contact_url
