Test case: missing_feed_info_date
Expected warning: Both feed start and end dates should be specified together
Error: feed_start_date is set but feed_end_date is missing
