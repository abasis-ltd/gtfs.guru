Test case: missing_pickup_drop_off_booking_rule_id
Expected warning: Flex trip with pickup/drop-off windows should have booking_rule_id
Warning: stop_times uses pickup/drop-off windows but pickup_booking_rule_id and drop_off_booking_rule_id are empty
