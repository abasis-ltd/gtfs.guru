Test case: missing_timepoint_value
Expected warning: When arrival or departure times exist, stop_times.timepoint should be defined
Error: stop_times has times but timepoint column is empty
