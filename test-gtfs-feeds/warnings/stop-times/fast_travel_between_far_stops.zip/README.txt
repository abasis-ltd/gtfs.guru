Test case: fast_travel_between_far_stops
Expected warning: Vehicle travels unrealistically fast between far stops
Warning: ~300km distance between NYC and Boston in 30 minutes = 600 km/h (impossible for rail)
