Test case: fast_travel_between_consecutive_stops
Expected warning: Transit vehicles exceeding speed thresholds between consecutive stops
Error: Trip travels ~14km in 30 seconds (impossibly fast for a bus)
