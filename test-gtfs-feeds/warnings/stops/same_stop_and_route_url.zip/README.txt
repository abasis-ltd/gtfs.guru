Test case: same_stop_and_route_url
Expected warning: Stop URLs should differ from route URLs
Error: stop_url 'https://example.com/route1' for stop1 is identical to route_url
