Test case: same_stop_and_agency_url
Expected warning: Stop URLs should differ from agency URLs
Error: stop_url 'https://example.com' for stop1 is identical to agency_url
