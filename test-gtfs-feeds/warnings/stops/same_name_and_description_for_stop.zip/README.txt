Test case: same_name_and_description_for_stop
Expected warning: Stop descriptions should offer unique details beyond stop names
Error: stop_desc 'First Stop' is identical to stop_name for stop1
