Test case: stop_without_stop_time
Expected warning: Stops defined but never used in trips
Error: stop3 'Unused Stop' is not referenced in stop_times.txt
