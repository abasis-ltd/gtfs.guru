Test case: pathway_loop
Expected warning: Pathways should not share identical start and end locations
Error: pathway1 has from_stop_id and to_stop_id both set to stop1
