Test case: pathway_dangling_generic_node
Expected warning: Generic nodes with only one pathway connection serve no purpose
Error: node1 (location_type=3) has only one pathway connection
